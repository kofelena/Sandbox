install.packages("likert")
library(likert)

data <- read.csv("/Users/Elena/OneDrive - Goldsmiths College/Term2/IS71044B Digital Sandbox/7 Assignments/SUS_results.csv",na.string="")

names(data) <- c(Respondent.ID = "ID",
                 Q1 = "I think that I would like to use this system frequently",
                 Q2 = "I found the system unnecessarily complex",
                 Q3 = "I thought the system was easy to use",
                 Q4 = "I think that I would need the support of a technical person to be able to use this system",
                 Q5 = "I found the various functions in this system were well integrated",
                 Q6 = "I thought there was too much inconsistency in this system",
                 Q7 = "I would imagine that most people would learn to use this system very quickly",
                 Q8 = "I found the system very cumbersome to use",
                 Q9 = "I felt very confident using the system",
                 Q10 = "I needed to learn a lot of things before I could get going with this system")

answers <- c('Strongly Disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly Agree')

data[2:11] <- lapply(data[2:11], factor, answers)

likert_data <- likert(data[2:11])

plot(likert_data) + theme(axis.text.y = element_blank()) +ggtitle("The System Usability Scale (SUS) questionnaire results")
